<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'pokeinfo' );

/** Database username */
define( 'DB_USER', 'pokeuser' );

/** Database password */
define( 'DB_PASSWORD', '=e7hBk4sK,p~jvbx' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'uQtG.RAkxe-+}oM[tArrF+,1mNgR)rPYt>@_T^NCa=FqK+9AJM1fPVSftClyXwa:' );
define( 'SECURE_AUTH_KEY',  '$$B-}kg~A`mx/W%-N2$6*diszvv9VpgW#T?1~n55U#@:C*mD8.]>~b(u2d^8-dr4' );
define( 'LOGGED_IN_KEY',    'x?}`M*>g*t3$Tnw/<B!`t+lwy$bcPh{3jjA.#a~/:j~Jl#~gjc/m-B%_&F!kuh-B' );
define( 'NONCE_KEY',        'f|}rKW3Na:MZU?u#pN,pc^KA [-z_6fY+uCE?M?Du9wGu)9ZB0i%rK</kT;W%?8X' );
define( 'AUTH_SALT',        'CIDWh[4]VEXi@8x=TvK^)!52X{P##TEK9c/utdG4N.@v}d5qO!>DnfQi/*8tms%J' );
define( 'SECURE_AUTH_SALT', '(CN+ NVf@hY~F`0Pr[u;,GQGjQ{LHmq`$nv0;CO9^6?Fex!6+Ma6F4DJ,|_0f}%i' );
define( 'LOGGED_IN_SALT',   ';3Re0Oq({(x=Y/xIHk:?u$G`Xn24K1HQ/6V3[Qi=v}{tQ+<~`Bg^W[bPnuta,k&{' );
define( 'NONCE_SALT',       '@<svgRrw~`xp=dv5SA;_Z5vX~.0EZ(K m|b?;l<REcc2:ZVCyUkrU#i.[PPz{D7J' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'pk_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
